package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class TebakActivity extends AppCompatActivity {

    private ImageView imageView_tebak;
    private EditText editText_jawabb;
    private Button button_cek;
    private String jawaban;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tebak);
        setInisialisasi();
        cekIntent();
        onClickJos();
    }

    private void onClickJos() {
        button_cek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editText_jawabb.getText().toString().equals(jawaban)) {
                    Toast.makeText(TebakActivity.this, "Yee Benar!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(TebakActivity.this, "oo Salah!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void cekIntent() {
        Intent cek = getIntent();
        String nama_hewan = cek.getStringExtra("nama_hewan");
        switch (nama_hewan) {
            case "anjing":
                imageView_tebak.setImageResource(R.drawable.anjing);
                jawaban = "anjing";
                break;
            case "kucing":
                imageView_tebak.setImageResource(R.drawable.kucing);
                jawaban = "kucing";
                break;
            case "ayam":
                imageView_tebak.setImageResource(R.drawable.ayam);
                jawaban = "ayam";
                break;
            default:
                imageView_tebak.setImageResource(R.drawable.landak);
                jawaban = "landak";
                break;
        }
    }

    private void setInisialisasi() {
        imageView_tebak = findViewById(R.id.imageView_tebak);
        editText_jawabb = findViewById(R.id.editText_jawab);
        button_cek = findViewById(R.id.buttonCek);
    }
}
