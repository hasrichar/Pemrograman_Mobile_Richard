package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView_kucing;
    private ImageView imageView_ayam;
    private ImageView imageView_landak;
    private ImageView imageView_anjing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setInisialisasi();
        onClickMantab();
    }

    private void onClickMantab() {
        imageView_ayam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(MainActivity.this, TebakActivity.class);
                d.putExtra("nama_hewan", "ayam");
                startActivity(d);
            }
        });
        imageView_landak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(MainActivity.this, TebakActivity.class);
                c.putExtra("nama_hewan", "landak");
                startActivity(c);
            }
        });
        imageView_kucing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, TebakActivity.class);
                a.putExtra("nama_hewan", "kucing");
                startActivity(a);
            }
        });
        imageView_anjing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent al = new Intent(MainActivity.this, TebakActivity.class);
                al.putExtra("nama_hewan", "anjing");
                startActivity(al);
            }
        });
    }

    private void setInisialisasi() {
        imageView_anjing = findViewById(R.id.imageView_anjing);
        imageView_kucing = findViewById(R.id.imageView_kucing);
        imageView_landak = findViewById(R.id.imageView_landak);
        imageView_ayam = findViewById(R.id.imageView_ayam);
    }
}

